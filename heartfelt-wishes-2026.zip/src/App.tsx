/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Heart, 
  Camera, 
  Sparkles, 
  ChevronRight, 
  ChevronLeft, 
  Palette, 
  MessageSquare, 
  Send,
  RefreshCcw,
  Check
} from 'lucide-react';
import { THEMES, INITIAL_DATA, type CardData, type ThemeId } from './constants';

export default function App() {
  const [step, setStep] = useState<'welcome' | 'details' | 'theme' | 'preview'>('welcome');
  const [data, setData] = useState<CardData>(INITIAL_DATA);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setData(prev => ({ ...prev, photoUrl: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const currentTheme = THEMES[data.themeId];

  return (
    <div className={`min-h-screen transition-colors duration-700 ${step === 'preview' ? currentTheme.bg : 'bg-stone-50'} overflow-x-hidden`}>
      <AnimatePresence mode="wait">
        {step === 'welcome' && (
          <motion.div
            key="welcome"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="flex flex-col items-center justify-center min-h-screen p-6 text-center"
          >
            <motion.div 
              animate={{ 
                scale: [1, 1.1, 1],
                rotate: [0, 5, -5, 0]
              }}
              transition={{ repeat: Infinity, duration: 4 }}
              className="mb-8"
            >
              <Heart size={64} className="text-rose-500 fill-rose-500/20" />
            </motion.div>
            <h1 className="mb-4 text-5xl font-display font-medium tracking-tight text-stone-900 md:text-6xl">
              Create a Moment <br/> <span className="text-rose-600">to Remember</span>
            </h1>
            <p className="max-w-md mb-10 text-lg text-stone-600 font-sans leading-relaxed">
              Design a beautiful, interactive digital birthday card for someone truly special. Heartfelt, personal, and unforgettable.
            </p>
            <button
              onClick={() => setStep('details')}
              id="start-creating-btn"
              className="group relative px-8 py-4 bg-stone-900 text-white rounded-full font-medium transition-all hover:pr-12 hover:bg-stone-800 focus:outline-none focus:ring-2 focus:ring-rose-500 focus:ring-offset-2"
            >
              Start Creating
              <ChevronRight className="absolute right-4 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-all" size={20} />
            </button>
          </motion.div>
        )}

        {step === 'details' && (
          <motion.div
            key="details"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            className="max-w-2xl mx-auto p-6 md:py-12"
          >
            <div className="flex items-center gap-3 mb-8">
              <button 
                onClick={() => setStep('welcome')}
                className="p-2 hover:bg-stone-200 rounded-full transition-colors"
              >
                <ChevronLeft size={20} />
              </button>
              <h2 className="text-2xl font-display font-semibold">Personalize the Wish</h2>
            </div>

            <div className="space-y-8 bg-white p-8 rounded-3xl shadow-sm border border-stone-100">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-2">Her Name</label>
                  <input
                    type="text"
                    value={data.recipientName}
                    onChange={e => setData({ ...data, recipientName: e.target.value })}
                    placeholder="e.g. Sarah"
                    className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500 outline-none transition-all"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-2">Your Name</label>
                  <input
                    type="text"
                    value={data.senderName}
                    onChange={e => setData({ ...data, senderName: e.target.value })}
                    placeholder="Your Name"
                    className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500 outline-none transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-stone-700 mb-2 text-center flex items-center gap-2 justify-center">
                  <Camera size={16} /> Add a Photo (Optional)
                </label>
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className="relative group cursor-pointer w-48 h-48 mx-auto bg-stone-50 border-2 border-dashed border-stone-200 rounded-3xl overflow-hidden flex items-center justify-center transition-all hover:border-rose-300"
                >
                  {data.photoUrl ? (
                    <img src={data.photoUrl} alt="Preview" className="w-full h-full object-cover" />
                  ) : (
                    <div className="text-center">
                      <Camera className="mx-auto mb-2 text-stone-400 group-hover:text-rose-400 transition-colors" size={32} />
                      <span className="text-xs text-stone-400 font-medium italic">Click to upload</span>
                    </div>
                  )}
                  {data.photoUrl && (
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <RefreshCcw className="text-white" size={24} />
                    </div>
                  )}
                </div>
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  onChange={handlePhotoUpload} 
                  accept="image/*" 
                  className="hidden" 
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-stone-700 mb-2 flex items-center gap-2">
                  <MessageSquare size={16} /> Your Heartfelt Message
                </label>
                <textarea
                  rows={4}
                  value={data.message}
                  onChange={e => setData({ ...data, message: e.target.value })}
                  className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500 outline-none transition-all resize-none"
                />
              </div>

              <button
                disabled={!data.recipientName}
                onClick={() => setStep('theme')}
                className="w-full py-4 bg-stone-900 text-white rounded-xl font-medium transition-all hover:bg-stone-800 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Choose Theme
              </button>
            </div>
          </motion.div>
        )}

        {step === 'theme' && (
          <motion.div
            key="theme"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            className="max-w-4xl mx-auto p-6 md:py-12"
          >
            <div className="flex items-center gap-3 mb-12">
              <button 
                onClick={() => setStep('details')}
                className="p-2 hover:bg-stone-200 rounded-full transition-colors"
              >
                <ChevronLeft size={20} />
              </button>
              <h2 className="text-2xl font-display font-semibold">Select an Aesthetic</h2>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              {(Object.keys(THEMES) as ThemeId[]).map((id) => {
                const theme = THEMES[id];
                return (
                  <motion.div
                    key={id}
                    whileHover={{ y: -10 }}
                    onClick={() => setData({ ...data, themeId: id })}
                    className={`cursor-pointer group relative p-1 rounded-[2.5rem] transition-all ${data.themeId === id ? 'ring-4 ring-rose-500/30' : 'hover:ring-2 hover:ring-stone-200'}`}
                  >
                    <div className={`h-80 ${theme.bg} rounded-[2rem] p-6 border ${theme.card} flex flex-col justify-between overflow-hidden relative`}>
                      <div className="absolute -top-10 -right-10 w-40 h-40 rounded-full opacity-10 bg-current filter blur-3xl animate-pulse" style={{ color: theme.accentColor }}></div>
                      
                      <div className={`text-xs uppercase tracking-widest font-bold ${theme.accent} mb-4`}>{theme.name}</div>
                      
                      <div className="space-y-3">
                        <div className={`h-2 w-3/4 rounded-full bg-stone-200/50`}></div>
                        <div className={`h-2 w-1/2 rounded-full bg-stone-200/50`}></div>
                        <div className={`h-2 w-5/6 rounded-full bg-stone-200/50`}></div>
                      </div>

                      <div className={`mt-auto text-lg ${theme.titleFont} font-medium ${theme.accent}`}>
                        Beautiful Typography
                      </div>

                      {data.themeId === id && (
                        <div className="absolute top-4 right-4 bg-rose-500 text-white p-1.5 rounded-full shadow-lg">
                          <Check size={14} />
                        </div>
                      )}
                    </div>
                    <div className="text-center mt-3 font-medium text-stone-600">{theme.name}</div>
                  </motion.div>
                );
              })}
            </div>

            <div className="mt-16 text-center">
              <button
                onClick={() => setStep('preview')}
                className="px-12 py-4 bg-stone-900 text-white rounded-full font-medium transition-all hover:bg-stone-800 scale-110 shadow-xl shadow-stone-200"
              >
                Preview Final Card
              </button>
            </div>
          </motion.div>
        )}

        {step === 'preview' && (
          <motion.div
            key="preview"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className={`fixed inset-0 z-50 flex items-center justify-center p-4 md:p-10 ${currentTheme.bg}`}
          >
            <div className="relative w-full max-w-5xl h-full flex flex-col md:flex-row bg-white rounded-[3rem] shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-700">
              {/* Left Side: Photo/Design */}
              <div className={`w-full md:w-1/2 h-64 md:h-full relative overflow-hidden flex items-center justify-center p-8 bg-stone-50`}>
                <div className="absolute inset-0 opacity-10" style={{ backgroundImage: `radial-gradient(circle at 2px 2px, ${currentTheme.accentColor} 1px, transparent 0)`, backgroundSize: '24px 24px' }}></div>
                
                <motion.div 
                  initial={{ scale: 0.85, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ 
                    duration: 1.2, 
                    delay: 0.4,
                    ease: [0.22, 1, 0.36, 1]
                  }}
                  className="relative z-10 w-full max-w-xs aspect-square"
                >
                  {/* Decorative Frame */}
                  <div className={`absolute -inset-4 border-2 ${currentTheme.card} rounded-3xl transform rotate-3`}></div>
                  <div className={`absolute -inset-4 border-2 ${currentTheme.card} rounded-3xl transform -rotate-3 opacity-50`}></div>
                  
                  <div className="w-full h-full bg-stone-200 rounded-2xl overflow-hidden shadow-2xl ring-8 ring-white">
                    {data.photoUrl ? (
                      <img src={data.photoUrl} alt={data.recipientName} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex flex-col items-center justify-center text-stone-400 p-8 text-center">
                        <Sparkles size={48} className="mb-4" />
                        <p className="font-serif italic">Your beautiful photo here</p>
                      </div>
                    )}
                  </div>
                </motion.div>

                <div className="absolute bottom-8 left-8 right-8 flex justify-between items-end">
                   <div className={`font-serif italic text-3xl ${currentTheme.accent} opacity-20`}>2026</div>
                   <Sparkles className={currentTheme.accent} size={24} />
                </div>
              </div>

              {/* Right Side: Message */}
              <div className="w-full md:w-1/2 h-full flex flex-col p-8 md:p-16 bg-white relative overflow-hidden">
                <motion.div
                   initial={{ opacity: 0, y: 20 }}
                   animate={{ opacity: 1, y: 0 }}
                   transition={{ delay: 0.6 }}
                   className="h-full overflow-y-auto pr-4 scrollbar-thin scrollbar-thumb-stone-200"
                >
                  <span className={`inline-block mb-4 text-xs font-bold uppercase tracking-[0.3em] ${currentTheme.accent}`}>Happy Birthday</span>
                  <h3 className={`text-4xl md:text-5xl ${currentTheme.titleFont} font-light leading-tight mb-8`}>
                    Happy Birthday, <br/>
                    <span className={`font-semibold ${currentTheme.accent}`}>{data.recipientName}</span>
                  </h3>
                  
                  <div className={`text-base md:text-lg leading-relaxed text-stone-600 ${currentTheme.bodyFont} mb-12 whitespace-pre-wrap italic opacity-90`}>
                    {data.message}
                  </div>

                  <div className="flex items-center gap-4 mt-auto pt-8 border-t border-stone-100">
                    <div className={`h-[1px] w-12 bg-stone-200`}></div>
                    <span className="text-sm font-medium tracking-widest text-stone-400 uppercase">Truly yours, {data.senderName}</span>
                  </div>
                </motion.div>

                {/* Desktop Action Bar */}
                <div className="absolute bottom-8 right-8 flex gap-4">
                  <button 
                    onClick={() => setStep('theme')}
                    className="p-3 bg-stone-100 text-stone-600 rounded-full hover:bg-stone-200 transition-all"
                  >
                    <Palette size={20} />
                  </button>
                  <button 
                    onClick={() => window.print()}
                    className="flex items-center gap-2 px-6 py-3 bg-stone-900 text-white rounded-full font-medium transition-all hover:scale-105 active:scale-95"
                  >
                    <Send size={18} /> Share Card
                  </button>
                </div>
              </div>
            </div>

            {/* Back to Edit Button */}
            <button 
              onClick={() => setStep('details')}
              className="fixed top-6 left-6 flex items-center gap-2 px-4 py-2 bg-white/80 backdrop-blur-sm border border-stone-200 rounded-full text-stone-600 text-sm font-medium transition-all hover:bg-white"
            >
              <ChevronLeft size={16} /> Edit Details
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      <footer className={`p-8 text-center text-stone-400 text-xs font-medium tracking-widest uppercase transition-opacity duration-500 ${step === 'preview' ? 'opacity-0 pointer-events-none' : 'opacity-100'}`}>
        Handcrafted for a special moment &bull; 2026 Edition
      </footer>
    </div>
  );
}


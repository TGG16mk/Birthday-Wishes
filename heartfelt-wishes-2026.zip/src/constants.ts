export const THEMES = {
  elegant: {
    id: 'elegant',
    name: 'Elegant Gold',
    bg: 'bg-stone-50',
    accent: 'text-amber-800',
    card: 'bg-white border-amber-100',
    titleFont: 'font-serif',
    bodyFont: 'font-serif',
    primaryBtn: 'bg-amber-800 text-stone-50',
    secondaryBtn: 'text-amber-900 border-amber-900',
    accentColor: '#B45309', // amber-700
  },
  serene: {
    id: 'serene',
    name: 'Serene Flora',
    bg: 'bg-emerald-50',
    accent: 'text-emerald-800',
    card: 'bg-white border-emerald-100',
    titleFont: 'font-display',
    bodyFont: 'font-sans',
    primaryBtn: 'bg-emerald-800 text-emerald-50',
    secondaryBtn: 'text-emerald-900 border-emerald-900',
    accentColor: '#065F46', // emerald-800
  },
  radiant: {
    id: 'radiant',
    name: 'Radiant Rose',
    bg: 'bg-rose-50',
    accent: 'text-rose-800',
    card: 'bg-white border-rose-100',
    titleFont: 'font-display',
    bodyFont: 'font-sans',
    primaryBtn: 'bg-rose-800 text-rose-50',
    secondaryBtn: 'text-rose-900 border-rose-900',
    accentColor: '#9F1239', // rose-800
  },
} as const;

export type ThemeId = keyof typeof THEMES;

export interface CardData {
  recipientName: string;
  senderName: string;
  message: string;
  photoUrl: string | null;
  themeId: ThemeId;
}

export const INITIAL_DATA: CardData = {
  recipientName: 'Muskan Sharma',
  senderName: 'Tejas Gautam',
  message: `Happy Birthday, Muskan 🎂✨

On this beautiful day, I just want to remind you how special you truly are. Your presence brings warmth, your smile spreads happiness, and your kindness touches everyone around you. You have a way of making even ordinary moments feel meaningful, and that’s something really rare.

May this year bless you with endless opportunities, beautiful memories, and the courage to chase every dream in your heart. I hope you always stay as genuine, strong, and wonderful as you are today.

Keep shining, keep smiling, and keep being YOU — because that’s your greatest magic.

---

**A Little Poem for You 💫**

Like the sunrise painting skies so bright,
You fill dull days with colors of light.
A gentle heart, a soul so true,
The world feels kinder because of you.

In every laugh, in every cheer,
You bring a warmth that draws hearts near.
Through every storm, through every glow,
Your strength and grace continue to grow.

So on this day, I wish for you,
Dreams that rise and all come true.
A life of joy, both deep and wide,
With love and hope always by your side.

Happy Birthday once again, Muskan 💖
May your story always be beautiful.
`,
  photoUrl: null,
  themeId: 'elegant',
};
